#ifndef initGPIO
#define initGPIO

unsigned int *getGPIOPtr(void);

unsigned int *getCLOPtr(void);

#endif